package com.example.himmerland;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;

public class e_login extends AppCompatActivity {

    private EditText Name;
    private EditText Password;
    private TextView Info;
    private Button Login;
    private int counter = 5;
    ImageButton openMenu;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.e_login);


        //LOGIN FUNKTIONEN!!! IKKE SLET!!!

        Name = (EditText)findViewById(R.id.login_name);
        Password = (EditText)findViewById(R.id.login__password);
        Info = (TextView)findViewById(R.id.login_attempts);
        Login = (Button)findViewById(R.id.login_button);

        Info.setText("Number of attempts remaining: 5");

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(Name.getText().toString(), Password.getText().toString());

            }
        });

    }

    private void validate (String userName, String userPassword) {
        if (userName.equals("Admin") && (userPassword.equals("1234"))) {
            Intent intent = new Intent(e_login.this, f_admin_page.class);
            startActivity(intent);
        }else{
            counter--;

            Info.setText("Number of attempts remaining: " + String.valueOf(counter));

            if (counter == 0) {
                Login.setEnabled(false);
            }
        }
//https://www.youtube.com/watch?v=lF5m4o_CuNg&ab_channel=ProfessorDK

//LOGIN FUNKTIONEN!!! IKKE SLET!!!

                    }
                }
