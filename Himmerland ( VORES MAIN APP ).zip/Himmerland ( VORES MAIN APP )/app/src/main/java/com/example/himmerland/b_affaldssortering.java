package com.example.himmerland;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.PopupMenu;

public class b_affaldssortering extends AppCompatActivity {

    ImageButton openMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.b_affaldssortering);


//DETTE SKAL BRUGET TIL VORES NAVIGERING!!!! IKKE SLET!!!!

        openMenu = findViewById(R.id.menuButton);

        openMenu.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                PopupMenu popupMenu = new PopupMenu(b_affaldssortering.this, v);
                popupMenu.getMenuInflater().inflate(R.menu.menu_popup_button, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.sortering:
                                Intent intent = new Intent(b_affaldssortering.this, b_affaldssortering.class);
                                startActivity(intent);
                                return true;

                            case R.id.rapportering:
                                intent = new Intent(b_affaldssortering.this, c_indrapportering.class);
                                startActivity(intent);
                                return true;

                            case R.id.storskrald:
                                intent = new Intent(b_affaldssortering.this, d_storskrald.class);
                                startActivity(intent);
                                return true;
                            default:
                                return false;
                        }
                    }
                });
                popupMenu.show();

            }
        });

        //DETTE SKAL BRUGET TIL VORES NAVIGERING!!!! IKKE SLET!!!!


        //HOME KNAPPEN!!!! IKKE SLET!!!

        ImageButton homebutton;

        homebutton = (ImageButton) findViewById(R.id.HomeButton);
        homebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intenthome = new Intent(b_affaldssortering.this, a_front_page.class);
                startActivity(intenthome);

            }
            //HOME KNAPPEN!!!! IKKE SLET!!!

            //DETTE ER TIL AT KOMME TIL LOGIN SIDEN!!! IKKE SLET!!!
            {
                openMenu = findViewById(R.id.settingsButton);

                openMenu.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        PopupMenu popupMenu = new PopupMenu(b_affaldssortering.this, v);
                        popupMenu.getMenuInflater().inflate(R.menu.menu_settings_button, popupMenu.getMenu());
                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                            @Override
                            public boolean onMenuItemClick(MenuItem item) {
                                switch (item.getItemId()) {
                                    case R.id.login:
                                        Intent intent = new Intent(b_affaldssortering.this, e_login.class);
                                        startActivity(intent);
                                        return true;
                                    default:
                                        return false;
                                }
                            }
                        });
                        popupMenu.show();

                        //DETTE ER TIL AT KOMME TIL LOGIN SIDEN!!! IKKE SLET!!!


                    }
                });
            }
        });
    }}