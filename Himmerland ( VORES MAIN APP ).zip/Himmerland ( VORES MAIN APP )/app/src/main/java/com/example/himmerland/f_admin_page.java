package com.example.himmerland;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class f_admin_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.f_admin_page);
    }
}